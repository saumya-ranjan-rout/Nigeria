import React, { useEffect, useState, useRef } from 'react';
import { useHistory } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import 'jquery/dist/jquery.min.js';
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons';
import 'datatables.net-buttons/js/buttons.html5';
import 'datatables.net-buttons/js/buttons.print';
import 'datatables.net-buttons-dt/css/buttons.dataTables.css';
import 'jszip';
import 'pdfmake';
import Sidebar from '../../../Sidebar';
import Header from '../../../Header';
import $ from 'jquery';
import 'react-datepicker/dist/react-datepicker.css';
import { useParams } from 'react-router-dom'

export function AddAssignOperatorNbraid() {
  const { id } = useParams()
  const [isActive, setActive] = useState(false);
  const [isSubMenuOpen, setSubMenuOpen] = useState(false);
  const [OpUserName, setOpUser] = useState('') 
  const [shift, setShift] = useState([])
  const [line, setLine] = useState([])
  const [section, setSection] = useState([])
  const [userId ,setUserid] = useState('');
  const [items ,setItems] = useState([]);
 
  const toggleClass = () => {
    setActive(!isActive);
  };

  const toggleSubMenu = () => {
    setSubMenuOpen(!isSubMenuOpen);
  };

  const history = useHistory();


    useEffect(() => {

       document.title = 'Add Assign Operator';
    // Check if the user is logged in
    const isLoggedIn = sessionStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
      // Redirect to the login page if not logged in
      history.push('/login');
    } else {

      const fetchUserName = () => {
        $.ajax({
          url: `http://192.168.29.12:4000/ikeja/operator_data_single/${id}`,
          method: 'GET',
          success: function (response) {
            setOpUser(response);
          },
          error: function (xhr, status, error) {
            console.error('Error fetching operator name:', error);
          },
        });
      };
      fetchUserName();
     
      // Fetch Shift type from API
        const fetchshift = () => {
            $.ajax({
            url: 'http://192.168.29.12:4000/getShiftOptions',
            method: 'GET',
            success: function (response) {
                setShift(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching shift options:', error);
            },
            });
        }
        fetchshift();

        // Fetch line type from API
        const fetchLine = () => {
            $.ajax({
            url: 'http://192.168.29.12:4000/ikeja/getlinemaster',
            method: 'GET',
            success: function (response) {
                setLine(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching line options:', error);
            },
            });
        }
        fetchLine();

        // Fetch section type from API
        const fetchSection = () => {
            $.ajax({
            url: 'http://192.168.29.12:4000/ikeja/getSection',
            method: 'GET',
            success: function (response) {
                setSection(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching section options:', error);
            },
            });
        }
        fetchSection();
     
    }
  }, []);

 //get user id
 useEffect(() => {
    if (OpUserName && OpUserName.entryid) {
      $.ajax({
        url: `http://192.168.29.12:4000/ikeja/getuserid/${OpUserName.entryid}`,
        method: 'GET',
        success: function (response) {
          setUserid(response);
        },
        error: function (xhr, status, error) {
          console.error('Error fetching operator name:', error);
        },
      });
    } else {
      console.error('OpUserName or entryid is undefined.');
    }
  }, [OpUserName]);

  //get items
  useEffect(() => {
    if (userId && userId.id) {
      $.ajax({
        url: `http://192.168.29.12:4000/ikeja/getSectionitem/${userId.id}`,
        method: 'GET',
        success: function (response) {
          setItems(response);
        },
        error: function (xhr, status, error) {
          console.error('Error fetching operator name:', error);
        },
      });
    } else {
      console.error('OpUserName or entryid is undefined.');
    }
  }, [userId]);

 //submit assign data
 const [formData, setFormData] = useState({
  shift: '',
  line:'',
  section:'',
  
});

const handleInputChange = (event) => {
  const { name, value } = event.target;
  setFormData({ ...formData, [name]: value });
};

const handleSubmit = (event) => {
  event.preventDefault();
  const insertFormdata = { ...formData, id: userId.id};
  const jsonData = JSON.stringify(insertFormdata);
  $.ajax({
    url: 'http://192.168.29.12:4000/ikeja/addSectionOp',
    method: 'POST',
    data: jsonData,
    processData: false,
    contentType: 'application/json',
    success: function (response){
         alert(response.message);
         window.location.reload();
        },
    error: function (xhr, status, error) {
      console.log(error);
    },
  });
}


  const handleDelete = (id) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this item?');
    if (confirmDelete) {
      $.ajax({
        url: `http://192.168.29.12:4000/ikeja/delete_section_assign/${id}`,
        method: 'DELETE',
        success: function (response) {
          alert(response);
          window.location.reload();
        },
        error: function (xhr, status, error) {
          console.error('Error deleting', error);
        },
      });
    }
  };
  let btnStyle = {
    color: 'white',
    fontSize: '10px',
    padding: '3px',
  }
  //////////////
  //Data table filter search
const [searchValue, setSearchValue] = useState('')
const handleSearchChange = (event) => {
  setSearchValue(event.target.value)
}

const filteredData = items.filter((row) => {
  return row.section_name.toLowerCase().includes(searchValue.toLowerCase())
})
//For check box
const [checkedItems, setCheckedItems] = useState([])
const [isChecked, setIsEnabled] = useState(false)

const handleCheckAll = (event) => {
  const { checked } = event.target

  if (checked) {
    setIsEnabled(true)
    // Get the IDs of all items in your table and set them in the state
    const allItemIds = items.map((item) => item.id)
    setCheckedItems(allItemIds)
  } else {
    setIsEnabled(false)
    // Uncheck all items
    setCheckedItems([])
  }
}
//Variable set for send tomove
const [checkboxValue, setCheckboxValue] = useState('')

const handleCheckSingle = (event, itemId) => {
  const { checked } = event.target
  setCheckboxValue(itemId)
  if (checked) {
    setIsEnabled(true)
    // Add the item ID to the checkedItems array
    setCheckedItems((prevCheckedItems) => [...prevCheckedItems, itemId])
  } else {
    setIsEnabled(false)
    // Remove the item ID from the checkedItems array
    setCheckedItems((prevCheckedItems) => prevCheckedItems.filter((id) => id !== itemId))
  }
}
 
  const handleMove = () => {
    const id=userId.id;
    const chkvalue = checkedItems.join(',');
    const redirectURL = `/hrm/ikeja/multiplesectionassign/${id}/${chkvalue}`;
    history.push(redirectURL);
  };
  return (
    <div className="container">
      <Sidebar />

      <section id="content">
        <Header />

        <main>
          <div className="container dt">
            <h5 className="title">Add New Section For   <span style={{color:'red'}}>{OpUserName.name}</span></h5>
            <hr></hr>
            <form  onSubmit={handleSubmit} method='POST'>
              <div className="row space">
                <div className="col-sm-3">
                    <span className="Shift">Shift</span>
                    <select className="form-control"  name="shift" value={formData.shift} onChange={handleInputChange}>
                    <option value="">Choose</option>
                    {shift.map((shiftnm) => (
                    <option
                        key={shiftnm.id}
                        value={shiftnm.name}
                    >
                        {shiftnm.name}
                    </option>
                    ))}
                    </select>
                </div>
                
                <div className="col-sm-3">
                    <span className="Shift"> Line </span>
                    <select className="form-control"  name="line" value={formData.line} onChange={handleInputChange}>
                    <option value="">Choose</option>
                    { line.map((lines) => (
                    <option
                        key={lines.id}
                        value={lines.line_name}
                    >
                        {lines.line_name}
                    </option>
                    ))}
                    </select>
                </div>
                   
                <div className="col-sm-3">
                    <span className="Shift"> Section Name </span>
                    <select className="form-control"  name="section" value={formData.section} onChange={handleInputChange}>
                    <option value="">Choose</option>
                    {section.map((data) => (
                    <option
                        key={data.id}
                        value={data.id}
                    >
                        {data.section_name}
                    </option>
                    ))}
                    </select>
                </div>  
                
                <div className="col-sm-2">
                  <button
                    type="submit"
                    className="btn btn-success btn-md"
                  >
                    Add
                  </button>
                </div>
              </div>
            </form>

            
            {/* Display Input Field Values */}
            <div style={{ display: 'flex' }}>
                  <input
                    className='form-control'
                    type="text"
                    value={searchValue}
                    onChange={handleSearchChange}
                    placeholder="Search..."
                    style={{ width: '80%' }}
                  /> &nbsp;&nbsp;
                  <button
                    className='btn btn-success'
                    style={{ color: '#fff' }}
                    disabled={!isChecked}
                    type="submit"
                    onClick={handleMove}
                  >
                    Move
                  </button>
                </div>


            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th><input type="checkbox" onChange={handleCheckAll} />All</th>
                    <th>slno</th>
                    <th>line</th>
                    <th>Section name</th>
                    <th>Shift</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                {filteredData.map((row, index) => (
                    <tr key={row.id}>
                      <td scope="row">
                        <input
                          type="checkbox"
                          checked={checkedItems.includes(row.id)}
                          onChange={(event) => handleCheckSingle(event, row.id)}
                          name="check[]"
                          value={row.id}
                        />
                      </td>
                      <td>{index + 1}</td>
                      <td>{row.line}</td>
                      <td>{row.section_name}</td>
                      <td>{row.shift}</td>
                      <td>
                        <button className="btn btn-danger" style={btnStyle} onClick={() => handleDelete(row.id)}>
                          <i class="bx bxs-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </section>
    </div>
  );
}

export default AddAssignOperatorNbraid;
